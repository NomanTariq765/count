import React from "react";
import "./App.css";

function App() {
  return (
    <main>Hello There, this is cool</main>
  );
}

export default App;
